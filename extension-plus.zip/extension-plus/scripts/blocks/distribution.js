const slagalloyStackConveyor = extend(StackConveyor, "slag-alloy-stack-conveyor", {
	speed: 6 / 60
});
const energizedplastaniumstackconveyor = extend(StackConveyor, "energized-plastanium-stack-conveyor", {
	speed: 4 / 60
});